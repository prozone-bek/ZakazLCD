import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackContext, MessageHandler, filters, CallbackQueryHandler
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime

import os

TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

zakazlar = []

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Zakazni quyidagi tartibda kiriting:\n\n"
                              "sana (dd.mm.yyyy)\nism familiya\nmahsulot\nnarx\n\n"
                              "Har birini yangi qatorda yozing.")

def parse_zakaz(text):
    try:
        lines = text.strip().split('\n')
        sana = lines[0]
        ism = lines[1]
        mahsulot = lines[2]
        narx = int(lines[3])
        zakaz = {
            "sana": sana,
            "ism": ism,
            "mahsulot": mahsulot,
            "narx": narx,
            "olingan": False
        }
        return zakaz
    except:
        return None

def handle_message(update: Update, context: CallbackContext):
    zakaz = parse_zakaz(update.message.text)
    if zakaz:
        zakazlar.append(zakaz)
        keyboard = [
            [
                InlineKeyboardButton("Pul OLINDI", callback_data=f"yes|{len(zakazlar)-1}"),
                InlineKeyboardButton("Pul OLINMAGAN", callback_data=f"no|{len(zakazlar)-1}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        update.message.reply_text(f"Zakaz qabul qilindi:\n\n{zakaz['ism']} - {zakaz['mahsulot']} - {zakaz['narx']} so'm", reply_markup=reply_markup)
    else:
        update.message.reply_text("Noto‘g‘ri format. Iltimos, to‘rt qator qilib kiriting.")

def button(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    action, idx = query.data.split('|')
    idx = int(idx)
    zakaz = zakazlar[idx]

    if action == "yes":
        zakaz["olingan"] = True
        query.edit_message_text(f"{zakaz['ism']} uchun zakaz to‘lovi OLINDI.")
    elif action == "no":
        zakaz["olingan"] = False
        query.edit_message_text(f"{zakaz['ism']} uchun zakaz to‘lovi HALI YO‘Q.")

def remind_payment(context: CallbackContext):
    chat_id = context.job.chat_id
    for idx, zakaz in enumerate(zakazlar):
        if not zakaz["olingan"]:
            context.bot.send_message(chat_id=chat_id, text=f"{zakaz['ism']} - {zakaz['mahsulot']} uchun pul hali olinmagan.")
            
def send_report(context: CallbackContext):
    chat_id = context.job.chat_id
    jami = len(zakazlar)
    olingan = sum(1 for z in zakazlar if z["olingan"])
    olinmagan = jami - olingan
    context.bot.send_message(chat_id=chat_id,
        text=f"Bugungi hisobot (soat 18:00):\n"
             f"Jami zakaz: {jami}\n"
             f"Olingan pul: {olingan} ta\n"
             f"Olinmagan: {olinmagan} ta")

async def schedule_jobs(application):
    scheduler = BackgroundScheduler()
    scheduler.start()

    async def add_jobs():
        for chat_id in application.chat_data.keys():
            scheduler.add_job(remind_payment, 'cron', hour=15, minute=0, args=[CallbackContext.from_update(Update(update_id=0), application)])
            scheduler.add_job(send_report, 'cron', hour=18, minute=0, args=[CallbackContext.from_update(Update(update_id=0), application)])

    await add_jobs()

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(button))

    app.run_polling()