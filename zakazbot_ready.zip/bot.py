import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from apscheduler.schedulers.background import BackgroundScheduler

TOKEN = "YOUR_BOT_TOKEN"

orders = []
scheduler = BackgroundScheduler()
scheduler.start()

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Salom! Buyurtma berish uchun:

Yozing: Ism Familiya, Mahsulot nomi, Narxi")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    parts = text.split(',')
    if len(parts) == 3:
        order = {
            "user": update.effective_user.first_name,
            "info": text.strip(),
            "paid": False
        }
        orders.append(order)
        await update.message.reply_text("Buyurtma qabul qilindi! Soat 15:00 da eslatma bo‘ladi.")
    else:
        await update.message.reply_text("Iltimos, quyidagi formatda yozing:
Ism Familiya, Mahsulot nomi, Narxi")

def send_payment_reminders(application):
    for order in orders:
        if not order["paid"]:
            application.bot.send_message(chat_id=order["user_id"], text="Eslatma: Buyurtma uchun to‘lov hali olinmagan.")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    scheduler.add_job(lambda: send_payment_reminders(app), 'cron', hour=15, minute=0)
    app.run_polling()
